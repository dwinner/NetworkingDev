namespace ShoppyExample
{
    internal class Discount
    {
    }
}