namespace Grouping
{
    enum Gender
    {
        Male,
        Female
    }
}